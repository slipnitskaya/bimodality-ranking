import os
import json
import tqdm
import argparse
import importlib
import numpy as np

from sklearn.base import ClusterMixin
from sklearn.base import ClassifierMixin
from sklearn.base import TransformerMixin

from typing import Any
from typing import Dict
from typing import List
from typing import Type
from typing import Union

RANDOM_SEED = 42


def load_class(package_name: str, class_name: str) -> Type:
    """
    Hand-made class loader. Its use makes possible to avoid "hardcoding" of Python imports.
    For instance, instead of writing "from sklearn.cluster import KMeans" we can load it dynamically during runtime.
    :param package_name: Python package (e.g., "numpy" or "sklearn.svm")
    :param class_name: Python class we wish to load (e.g., "SVC" from package "sklearn.svm")
    :return: class that should be instantiated later
    """
    importlib.invalidate_caches()

    package = importlib.import_module(package_name)
    clazz = getattr(package, class_name)

    return clazz


def run(experiment_name: str,
        experiment_desc: str,
        model_class: str,
        model_args: Dict[str, Any],
        dataset_class: str,
        dataset_args: Dict[str, Any],
        transforms: List[Dict[str, Union[str, Dict[str, Any]]]],
        metric_class: str,
        metric_args: Dict[str, Any],
        saver_class: str,
        saver_args: Dict[str, Any]):

    """
    The core of the framework. Defines the whole pipeline of the experiment.
    This pipeline includes 5 pre-defined steps:
        1. data loading from dataset;
        2. data transform;
        3. model training;
        4. model evaluation;
        5. results saving.
    The ultimate requirement to all these steps is to keep data format compatible for the following ones.
    For instance, that means that you can swap scaling and logarithm during transformation step
    (have no idea why; because you can) and the pipeline won't be broken.
    :param experiment_name: unique name of the experiment
    :param experiment_desc: description of the experiment to avoid its  encoding into experiment_name
    :param model_class: name of the model's class
    :param model_args: arguments to instantiate model from the model_class
    :param dataset_class: name of the dataset's class
    :param dataset_args: arguments to instantiate dataset from the dataset_class
    :param transforms: list of transforms to apply to data loaded from the dataset
    :param metric_class: name of the metric's class
    :param metric_args: arguments to instantiate metric from the metric_class
    :param saver_class: name of the saver's class
    :param saver_args: arguments to instantiate saver from the saver_class
    :return:
    """

    print(f'Starting "{experiment_name}":\n-> {experiment_desc}')

    # load dataset's class
    Dataset: Type = load_class(*dataset_class.rsplit('.', 1))
    # instantiate dataset's objects, one provides training samples, another provides test samples
    dataset_train = Dataset(**{**dataset_args, **{'training': True}})
    dataset_test = Dataset(**{**dataset_args, **{'training': False}})

    # load classes and instantiate transforms' objects which are kept in the order they should be applied
    data_transforms: List[Any, TransformerMixin] = list()
    for idx, transform in enumerate(transforms):
        data_transforms.append(load_class(*transform['class'].rsplit('.', 1))(**transform['args']))

    # load model's class
    Model: Type[Any, Union[ClusterMixin, ClassifierMixin]] = load_class(*model_class.rsplit('.', 1))
    # instantiate model's object using provided arguments
    model = Model(**model_args)

    # load metric's class
    Metric: Type = load_class(*metric_class.rsplit('.', 1))
    # instantiate metric's object using provided arguments
    metric = Metric(**metric_args)

    # load saver's class
    Saver: Type = load_class(*saver_class.rsplit('.', 1))
    # instantiate saver's object using provided arguments
    saver = Saver(**saver_args)

    eval_results = list()
    # now iterate over train and test datasets
    # here, one entry corresponds to one *.npy or *.pkl file
    for entry_train, entry_test in tqdm.tqdm(zip(dataset_train, dataset_test), total=len(dataset_train)):
        # STEP_1
        # get filename we loaded samples from
        entry_fname: str = entry_train['filename']
        # get description of the loaded data (e.g., generation parameters)
        entry_desc: str = entry_train['item']['desc']

        # get actual train samples and their labels
        X_train: np.ndarray = entry_train['item']['X']
        y_train: np.ndarray = entry_train['item']['y']

        # get actual test samples and their labels
        X_test: np.ndarray = entry_test['item']['X']
        y_test: np.ndarray = entry_test['item']['y']
        # END_STEP_1

        # STEP_2
        # sequentially apply each transform to the data
        for transform in data_transforms:
            transform = transform.fit(X_train, y_train)

            if hasattr(transform, 'transform'):
                X_train = transform.transform(X_train)
                X_test = transform.transform(X_test)
            else:
                X_train = transform.fit_transform(X_train, y_train)
                X_test = transform.fit_transform(X_test, y_test)
        # END_STEP_2

        # STEP_3
        # train model on the transformed data
        model = model.fit(X_train, y_train)
        # END_STEP_3

        # STEP_4
        # obtain predictions from the trained model
        y_pred: np.ndarray = model.predict(X_test)
        # evaluate model's performance
        performance: float = metric(y_test, y_pred)
        # END_STEP_4

        # TODO: probably, it makes sense to encapsulate report generation into separate class
        # store evaluation results
        eval_results.append({
            'filename': entry_fname,
            'desc': entry_desc,
            'perf': str(performance),
            'X_train': X_train,
            'y_train': y_train,
            'X_test': X_test,
            'y_test': y_test,
            'y_pred': y_pred
        })

    # STEP_5
    # save experiment results
    saver.save(eval_results)
    # END_STEP_5


def main():
    """
    Entry point that handles all the arguments preparation for the run() function.
    :return:
    """
    parser = argparse.ArgumentParser()

    parser.add_argument('-c', '--config', type=str, required=True)
    parser.add_argument('-r', '--random-seed', type=int, required=False)

    args = parser.parse_args()

    # first, we load experimental setup from the JSON file
    # more info about JSON format: https://www.json.org/
    config = json.load(open(args.config))

    # the unique experiment name is obtained from the filename
    experiment_name = str(os.path.splitext(os.path.basename(args.config))[0])
    # if description isn't provided, use empty string
    experiment_desc = config['Setup']['description'] or ''

    # set random seed in order to make results reproducible
    random_seed = int(args.random_seed or config['Setup']['random_seed'] or RANDOM_SEED)
    np.random.seed(random_seed)

    # get class names and corresponding arguments from the config
    model_class = config['Model']['class']
    model_args = config['Model']['args']
    dataset_class = config['Dataset']['class']
    dataset_args = config['Dataset']['args']
    transforms = config['Transforms']
    metric_class = config['Metric']['class']
    metric_args = config['Metric']['args']
    saver_class = config['Saver']['class']
    saver_args = config['Saver']['args']

    # run the experiment
    run(
        experiment_name=experiment_name,
        experiment_desc=experiment_desc,
        model_class=model_class,
        model_args=model_args,
        dataset_class=dataset_class,
        dataset_args=dataset_args,
        transforms=transforms,
        metric_class=metric_class,
        metric_args=metric_args,
        saver_class=saver_class,
        saver_args=saver_args
    )
