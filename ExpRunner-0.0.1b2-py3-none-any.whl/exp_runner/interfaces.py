import abc

from typing import Any


"""
This file keeps common interfaces to be implemented.
Currently, it's a placeholder where we store stuff for the future.
Once exp_runner.py becomes stable, it will be converted into a package we can install.
"""


class Dataset(abc.ABC):

    @abc.abstractmethod
    def __getitem__(self, index: int) -> Any:
        pass

    @abc.abstractmethod
    def __len__(self) -> int:
        pass

    @property
    @abc.abstractmethod
    def training(self) -> bool:
        pass


class Saver(abc.ABC):

    @abc.abstractmethod
    def save(self, report: Any) -> None:
        pass
